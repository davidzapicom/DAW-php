<h1>Ejemplos de errores</h1>

<p>Os recomiendo ver tanto el código como la ejecución de los siguientes ficheros de manera simultanea, para que lo entendáis mejor.</p>

<p>Seguidlos en el orden que os los pongo, ya que unos hacen referencia a los anteriores</p>

<ul>
	<li><a href="die.php">La función die</a></li>
	<li><a href="excepciones.php">Excepciones (1 de 2)</a></li>
	<li><a href="excepciones2.php">Excepciones (2 de 2)</a></li>
	<li><a href="errores.php">Errores</a></li>
</ul>