<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <a href="ejercicio2.php">Crear agenda diaria</a>
    <br>
    <a href="ejercicio3.php">Mostrar agenda diaria</a>
    <br>
    <a href="#">Estadísticas de uso</a>
</body>
</html>